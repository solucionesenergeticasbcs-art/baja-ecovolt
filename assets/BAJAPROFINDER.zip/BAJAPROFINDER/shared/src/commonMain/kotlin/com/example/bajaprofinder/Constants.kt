package com.example.bajaprofinder

const val SERVER_PORT = 8080