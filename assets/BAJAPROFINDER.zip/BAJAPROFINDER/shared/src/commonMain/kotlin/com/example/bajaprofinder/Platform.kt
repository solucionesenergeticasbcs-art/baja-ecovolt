package com.example.bajaprofinder

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform